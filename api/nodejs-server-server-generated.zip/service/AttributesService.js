'use strict';


/**
 * Devices attributes
 *
 * no response value expected for this operation
 **/
exports.attributesGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Server heartbeat operation. Get information about devices attributes types.
 * Dictionary attributes types of specific type of device.
 *
 * no response value expected for this operation
 **/
exports.attributes_typesGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

