'use strict';


/**
 * Server heartbeat operation. Get information about connection between Devices.
 * Connection between devices
 *
 * no response value expected for this operation
 **/
exports.connectionsGET = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

